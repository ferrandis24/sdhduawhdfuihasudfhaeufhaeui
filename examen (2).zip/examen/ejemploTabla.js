//actividad3
document.addEventListener('DOMContentLoaded', () => {
    let elemButton = document.createElement('button')
    elemButton.id = 'boton'
    elemButton.textContent = 'cambia'
    document.body.appendChild(elemButton)

    elemButton.addEventListener('click', (event) => {
        let elemTbody = document.getElementsByTagName('tBody')[0];
        let elemTr = Array.from(elemTbody.getElementsByTagName('tr'));

        for (let i = elemTr.length - 1; i >= 0; i--) {
            elemTbody.appendChild(elemTr[i]);

        }


    })
//actividad4

    let elemButtonPromt = document.createElement('button')
    elemButtonPromt.id = 'boton2'
    elemButtonPromt.textContent = 'añade'
    document.body.appendChild(elemButtonPromt)
    elemButtonPromt.addEventListener('click', (event) => {
        let nombre = prompt('dame el nombre')
        let apellidos = prompt('dame el apellidos')
        let despacho = prompt('dame despacho')
        let correo = prompt('dame correo')
        let elemTbody = document.getElementsByTagName('tBody')[0];
        let elemfila = document.createElement('tr')
        let elemColumn = document.createElement('td')
        let elemColumn2 = document.createElement('td')
        let elemColumn3 = document.createElement('td')
        let elemColumn4 = document.createElement('td')
        elemColumn.textContent = nombre
        elemColumn2.textContent = apellidos
        elemColumn3.textContent = despacho
        elemColumn4.textContent = correo
        elemfila.appendChild(elemColumn)
        elemfila.appendChild(elemColumn2)
        elemfila.appendChild(elemColumn3)
        elemfila.appendChild(elemColumn4)
        elemTbody.appendChild(elemfila)







    })
    //actividad5

    let deleteRow = document.createElement('button')
    deleteRow.id = 'boton2'
    deleteRow.textContent = 'elimina'
    document.body.appendChild(deleteRow)
    deleteRow.addEventListener(
        'click', (event) => {
        document.getElementById("myTable").deleteRow(3);
      })
    })

      




    

